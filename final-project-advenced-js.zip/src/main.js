import "./js/header.js";
import "./js/burger.js";

import "./js/pagination/pagination.js";
import './js/exercises-right-part-filter.js';
import './js/subscribe.js';
import './js/notifications.js';

import './js/authentication.js';
import './js/search.js';
import './js/loader/loader.js';
import './js/modal-window/modal.js';
import './js/sendEmail.js';
import './js/filter.js';
import './js/exercises.js';
import './js/quote.js';
import './js/pagination/pagination.js';
import './js/scrollToTopButton';
import './js/raiting.js';
