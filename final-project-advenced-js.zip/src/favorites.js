import "./js/header.js";
import "./js/burger.js";
// import "./js/authentication.js";
// import "./js/favorite.js";
// import "./js/modal-window/modal.js";
// import "./js/quote.js";
// import "./js/scrollToTopButton.js";
// import "./js/exercises-right-part-filter.js";
// import "./js/raiting.js";
